package com.raj.projectnixie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DateSetTimezone extends AppCompatActivity {
    private static final String TAG = "DateSetTimeZone";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_set_timezone);
    }
}
