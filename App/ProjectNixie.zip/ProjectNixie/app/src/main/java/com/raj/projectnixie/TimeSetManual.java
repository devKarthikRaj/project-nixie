package com.raj.projectnixie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TimeSetManual extends AppCompatActivity {
    private static final String TAG = "TimeSetManual";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_set_manual);
    }
}
